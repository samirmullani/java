package Day10;

import java.io.*;
import java.util.*;

public class ClassGenerator {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        String packageName, className;
        List<String> fields = new ArrayList<>();
        List<String> methods = new ArrayList<>();

        System.out.print("Enter package name: ");
        packageName = sc.nextLine();

        System.out.print("Enter class name: ");
        className = sc.nextLine();

        System.out.println("Choose class access specifier: 1. public  2. default");
        int specChoice = sc.nextInt();
        sc.nextLine();
        String classAccess = (specChoice == 1) ? "public " : "";

        int choice;
        do {
            System.out.println("\n1. Add Field");
            System.out.println("2. Add Method");
            System.out.println("3. Generate Class");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine();

			switch (choice) {
			case 1:
				System.out.print("Enter data type: ");
				String type = sc.nextLine();
				System.out.print("Enter access specifier (public/private/protected/default): ");
				String fAccess = sc.nextLine();
				System.out.print("Enter variable name: ");
				String var = sc.nextLine();
				fields.add(fAccess + " " + type + " " + var + ";");
				break;

			case 2:
				System.out.print("Enter return type: ");
				String ret = sc.nextLine();
				System.out.print("Enter access specifier (public/private/protected/default): ");
				String mAccess = sc.nextLine();
				System.out.print("Enter parameters (type name, comma-separated): ");
				String params = sc.nextLine();
				System.out.print("Enter method name: ");
				String mName = sc.nextLine();
				methods.add(mAccess + " " + ret + " " + mName + "(" + params + ") {\n\t// TODO: code here\n}");
				break;

			case 3:
				generateJavaFile(packageName, className, classAccess, fields, methods);
				System.out.println("Class generated successfully as " + className + ".java");
				break;
			}
		} while (choice != 3);
		sc.close();
	}

    static void generateJavaFile(String pkg, String cname, String access, List<String> fields, List<String> methods) throws Exception {
        FileWriter fw = new FileWriter(cname + ".java");
        fw.write("package " + pkg);
        fw.write(access + "class " + cname );
        for (String f : fields)
            fw.write("    " + f );
        fw.write("\n");
        for (String m : methods)
            fw.write("    " + m );
        fw.write(" ");
        fw.close();
    }
}
