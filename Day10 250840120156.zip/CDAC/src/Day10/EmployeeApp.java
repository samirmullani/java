package Day10;
import java.io.*;
import java.util.*;

class Employee implements Serializable {
    private int id;
    private String name;
    private double salary;

    public Employee(int id, String name, double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee [ID=" + id + ", Name=" + name + ", Salary=" + salary + "]";
    }
}

public class EmployeeApp {
    private static final String FILE_NAME = "employees.ser";
    private static LinkedList<Employee> empList = new LinkedList<>();

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- Employee Menu ---");
            System.out.println("1. Add Employee");
            System.out.println("2. Display Employees");
            System.out.println("3. Save (Serialize)");
            System.out.println("4. Load (Deserialize)");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Salary: ");
                    double sal = sc.nextDouble();
                    empList.add(new Employee(id, name, sal));
                    break;

                case 2:
                    System.out.println("\nEmployee List:");
                    for (Employee e : empList)
                        System.out.println(e);
                    break;

                case 3:
                    saveToFile();
                    break;

                case 4:
                    loadFromFile();
                    break;

                case 5:
                    System.out.println("Exiting...");
                    break;
            }
        } while (choice != 5);
        sc.close();
    }

    static void saveToFile() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(empList);
            System.out.println("Employees saved successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void loadFromFile() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            empList = (LinkedList<Employee>) ois.readObject();
            System.out.println("Employees loaded successfully!");
        } catch (Exception e) {
            System.out.println("Error loading file or file not found.");
        }
    }
}
