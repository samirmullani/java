package Day10.FileHandling;

import java.io.File;

public class CheckExist {
    public static void main(String[] args) {
        File f = new File("C:\\Users\\OneDrive\\Desktop\\CDAC Java\\java.txt");
        System.out.println(f.exists() ? "Exists" : "Does not exist");
    }
}

