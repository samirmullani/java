package Day10.FileHandling;

import java.io.File;

public class CheckType {
    public static void main(String[] args) {
        File f = new File("C:\\Users\\samir\\OneDrive\\Desktop");
        
        if (f.isDirectory()) System.out.println("It is a directory");
        else if (f.isFile()) System.out.println("It is a file");
       

        
    }
}
