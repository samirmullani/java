package Day10.FileHandling;

import java.io.*;

public class CopyFile {
    public static void main(String[] args) throws Exception {
        FileInputStream in = new FileInputStream("C:\\Users\\Samir\\OneDrive\\Desktop\\source.txt");
        FileOutputStream out = new FileOutputStream("C:\\Users\\Samir\\OneDrive\\Desktop\\dest.txt");
        int b;
        while ((b = in.read()) != -1)
            out.write(b);
        in.close();
        out.close();
        System.out.println("File copied successfully.");
    }
}
