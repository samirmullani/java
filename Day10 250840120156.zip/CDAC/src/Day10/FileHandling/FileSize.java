package Day10.FileHandling;

import java.io.File;

public class FileSize {
    public static void main(String[] args) {
        File f = new File("C:\\Users\\samir\\OneDrive\\Desktop\\CDAC Java");
        if (f.exists()) {
            long bytes = f.length();
            System.out.println("Bytes: " + bytes);
            System.out.println("KB: " + (bytes / 1024.0));
            System.out.println("MB: " + (bytes / (1024.0 * 1024)));
        }
    }
}
