package Day10.FileHandling;
import java.io.File;

public class FilesByExtension {
	public static void main(String[] args) {
		File folder = new File("C:\\Users\\samir\\OneDrive\\Desktop");
		File[] files = folder.listFiles((dir, name) -> name.endsWith(".txt"));
		for (File f : files)
		System.out.println(f.getName());
	}
}
