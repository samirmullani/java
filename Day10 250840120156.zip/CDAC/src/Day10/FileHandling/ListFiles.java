package Day10.FileHandling;
import java.io.File;

public class ListFiles {
	public static void main(String[] args) {
		File folder = new File("C:\\Users\\samir\\OneDrive\\Desktop\\CDAC Java");
		String[] names = folder.list();
		for (String name : names)
			System.out.println(name);
	}
}


