package Day10.FileHandling;
import java.util.*;
import java.io.*;

public class LongestWord {
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\samir\\OneDrive\\Desktop\\source.txt"));
		String line, longest = "";
		while ((line = br.readLine()) != null) 
		{
		  for (String word : line.split("\\W+"))
		  {
			 if (word.length() > longest.length())
				  longest = word;
			}
		}
        br.close();
        System.out.println("Longest word: " + longest);
    }
}
