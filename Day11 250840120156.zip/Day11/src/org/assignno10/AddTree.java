package org.assignno10;

import java.util.TreeSet;

public class AddTree {

	public static void main(String[] args) {
		TreeSet<String> color=new TreeSet<>();
		color.add("red");
		color.add("yellow");
		color.add("black");
		color.add("white");
		color.add("pink");
		color.add("orange");
		TreeSet<String> color1=new TreeSet<>(color);

System.out.println("color :");
		
		for(String colors:color1) {
			System.out.println(colors);
	}

	}

	}


