package org.assignno10;

import java.util.ArrayList;
import java.util.Collections;

public class CopyArray {

	public static void main(String[] args) {
		ArrayList<String> color=new ArrayList<>();
		color.add("red");
		color.add("yellow");
		color.add("black");
		ArrayList<String> color1=new ArrayList<>(color);
		

System.out.println("copy color :"+color1);
	}

}
