package org.assignno10;

public class EmpApp {

	public static void main(String[] args) {
		

	}

}
