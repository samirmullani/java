package org.assignno10;

public class EmpCollectionFramework {

	public static void main(String[] args) {
		

	}

}
