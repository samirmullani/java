package org.assignno10;

import java.util.TreeSet;

public class FirstLast {

	public static void main(String[] args) {
		TreeSet<String> color=new TreeSet<>();
		color.add("red");
		color.add("yellow");
		color.add("black");
		color.add("white");
		color.add("pink");
		color.add("orange");
		for(String colors:color) {
			System.out.println(colors);
	}

			System.out.println("first : "+color.first()+"\nlast : "+color.last());
	}
}


