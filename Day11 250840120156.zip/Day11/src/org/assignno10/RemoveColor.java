package org.assignno10;

import java.util.ArrayList;

public class RemoveColor {

	public static void main(String[] args) {
		ArrayList<String> color=new ArrayList<>();
		color.add("red");
		color.add("yellow");
		color.add("black");
		color.remove(2);

System.out.println("color :");
		
		for(String colors:color) {
			System.out.println(colors);
	}

	}}
