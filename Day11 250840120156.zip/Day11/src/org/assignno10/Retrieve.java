package org.assignno10;

import java.util.ArrayList;

public class Retrieve {
	
public static void main(String[]args) {
	ArrayList<String> color=new ArrayList<>();
	color.add("red");
	color.add("yellow");
	color.add("black");
	
	
	System.out.println("color :"+color.get(1));
	
	

}
}
