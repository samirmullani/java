package org.assignno10;

import java.util.TreeSet;

public class ReverseTree {

	public static void main(String[] args) {
		TreeSet<String> color=new TreeSet<>();
		color.add("red");
		color.add("yellow");
		color.add("black");
		color.add("white");
		color.add("pink");
		color.add("orange");
		color.first();
		color.last();
	  
System.out.println("color :"+  color.descendingSet());
		
		for(String colors:color) {
			System.out.println(colors);
	}

	}

	
	}


