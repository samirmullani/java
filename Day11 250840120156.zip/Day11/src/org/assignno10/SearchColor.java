package org.assignno10;

import java.io.Closeable;
import java.time.chrono.IsoChronology;
import java.util.ArrayList;
import java.util.Scanner;

public class SearchColor {

	public static void main(String[] args) {
		ArrayList<String> color=new ArrayList<>();
		color.add("red");
		color.add("yellow");
		color.add("black");
		Scanner scanner=new Scanner(System.in);
	
		System.out.println("Enter color to search: ");
		String SearchColor =scanner.next();
		if(color.contains(SearchColor.toLowerCase())) {
			System.out.println( "color is found !");
		}else {
			System.out.println("color is not found !");
		}
	
	}

}