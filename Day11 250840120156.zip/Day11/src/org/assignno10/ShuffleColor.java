package org.assignno10;

import java.util.ArrayList;
import java.util.Collections;

public class ShuffleColor {

	public static void main(String[] args) {
		ArrayList<String> color=new ArrayList<>();
		color.add("red");
		color.add("yellow");
		color.add("black");
		Collections.shuffle(color);
		

System.out.println("shuffled color :"+color);
	}



	}

