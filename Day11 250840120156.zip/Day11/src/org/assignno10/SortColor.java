package org.assignno10;

import java.util.ArrayList;
import java.util.Collections;
import java.util.TreeSet;

public class SortColor {

	public static void main(String[] args) {
		
		TreeSet<String> color=new TreeSet<>();
		color.add("red");
		color.add("yellow");
		color.add("black");
		

System.out.println("color :");
		
		for(String colors:color) {
			System.out.println(colors);
	}

	}

	}




