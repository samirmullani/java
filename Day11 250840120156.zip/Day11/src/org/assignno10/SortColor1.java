package org.assignno10;

import java.util.ArrayList;
import java.util.Collections;


public class SortColor1 {

	public static void main(String[] args) {
		
	
			ArrayList<String> color=new ArrayList<>();
			color.add("red");
			color.add("yellow");
			color.add("black");
			Collections.sort(color);

	System.out.println("color :");
			
			for(String colors:color) {
				System.out.println(colors);
		}

		}

		

	}


