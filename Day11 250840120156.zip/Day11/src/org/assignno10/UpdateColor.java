package org.assignno10;

import java.util.ArrayList;

public class UpdateColor {

	public static void main(String[] args) {
		ArrayList<String> color=new ArrayList<>();
		color.add("red");
		color.add("yellow");
		color.add("black");
		color.set(0, "pink");
		color.set(1, "purple");
		color.set(2, "green");
             
		
		System.out.println("colors:"+color);
	}
	
	

}
