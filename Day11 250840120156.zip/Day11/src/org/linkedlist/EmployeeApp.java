package org.linkedlist;

import java.util.LinkedList;
import java.util.Scanner;

public class EmployeeApp {
    public static void main(String[] args) {
        LinkedList<Employee> employeeList = new LinkedList<>();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n----- Employee Management System -----");
            System.out.println("1. Add Employee");
            System.out.println("2. Display All Employees");
            System.out.println("3. Search Employee by ID");
            System.out.println("4. Delete Employee by ID");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Employee ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); // consume newline
                    System.out.print("Enter Employee Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Employee Salary: ");
                    double salary = scanner.nextDouble();

                    employeeList.add(new Employee(id, name, salary));
                    System.out.println("Employee added successfully!");
                    break;

                case 2:
                    if (employeeList.isEmpty()) {
                        System.out.println("No employees to display.");
                    } else {
                        System.out.println("\n--- Employee List ---");
                        for (Employee e : employeeList) {
                            e.display();
                        }
                    }
                    break;

                case 3:
                    System.out.print("Enter Employee ID to search: ");
                    int searchId = scanner.nextInt();
                    boolean found = false;
                    for (Employee e : employeeList) {
                        if (e.id == searchId) {
                            System.out.println("Employee Found:");
                            e.display();
                            found = true;
                            break;
                        }
                    }
                    if (!found) System.out.println("Employee not found.");
                    break;

                case 4:
                    System.out.print("Enter Employee ID to delete: ");
                    int deleteId = scanner.nextInt();
                    Employee toRemove = null;
                    for (Employee e : employeeList) {
                        if (e.id == deleteId) {
                            toRemove = e;
                            break;
                        }
                    }
                    if (toRemove != null) {
                        employeeList.remove(toRemove);
                        System.out.println("Employee deleted successfully.");
                    } else {
                        System.out.println("Employee not found.");
                    }
                    break;

                case 5:
                    System.out.println(" Exiting the program...");
                    break;

                default:
                    System.out.println(" Invalid choice! Please try again.");
            }

        } while (choice != 5);

        scanner.close();
    }
}


