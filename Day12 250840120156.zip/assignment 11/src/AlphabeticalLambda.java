import java.util.Arrays;
import java.util.function.Consumer;

public class AlphabeticalLambda {

	public static void main(String[] args) {
		Consumer<String[]>sortStrings =arr->{
			Arrays.sort(arr,String::compareToIgnoreCase);
			System.out.println(Arrays.toString(arr));
		

	};
	
	String[] color= {"Green","Yellow","Red","Black"};
	sortStrings.accept(color);
}


}
