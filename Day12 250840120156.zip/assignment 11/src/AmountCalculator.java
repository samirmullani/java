
@FunctionalInterface
interface AmountCalculator {
  float  calculate(Transactions tx);
}


