import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class AmountDue {

    public static void main(String[] args) {
        List<Transactions> transactions = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        final int NumOfTransaction = 2;

        System.out.println("----Enter transaction details---");

        for (int i = 1; i <= NumOfTransaction; i++) {
            System.out.println("\nEnter transaction details for transaction " + i + ":");

            System.out.print("Enter ID: ");
            int txid = scanner.nextInt();

            System.out.print("Enter Date (YYYY-MM-DD): ");
            scanner.nextLine();
            String dateString = scanner.nextLine();
            LocalDate txDate = LocalDate.parse(dateString);

            System.out.print("Enter Amount: ");
            int txAmount = scanner.nextInt();

            System.out.print("Enter Status (true/false): ");
            boolean txStatus = scanner.nextBoolean();

            System.out.print("Enter Arrears (true/false): ");
            boolean txArrears = scanner.nextBoolean();

            Transactions txTransaction = new Transactions(txid, txDate, txAmount, txStatus, txArrears);
            transactions.add(txTransaction);

            System.out.println("Transaction " + i + " added to the collection.");
        }

        scanner.close();

        // Display all transactions
        System.out.println("\n==================================");
        System.out.println("Contents of ALL transactions:");
        transactions.forEach(System.out::println);
        System.out.println("==================================");

        // Process using TransactionApp
        TransactionApp app = new TransactionApp();
        List<Transactions> highValueTransactions = app.filterHighValueTransactions(transactions);

        System.out.println("\nSummary of high-value transactions: " + highValueTransactions.size() + " found.");
        highValueTransactions.forEach(System.out::println);
    }

    // Lambda-based amount calculator
    private static final AmountCalculator AMOUNT_DUE = tx -> {
        float amount = tx.getTxAmount();
        if (tx.isTxArrears()) {
            double interest = amount * 0.18;
            return (int) (amount + 500 + interest);
        } else {
            return amount;
        }
    };
}