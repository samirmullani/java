import java.time.LocalDate;

public class CurrentDate {

	public static void main(String[] args) {
		Runnable CurDate=()->System.out.println("Current Date : " + LocalDate.now());
		
		CurDate.run();
	}

}
