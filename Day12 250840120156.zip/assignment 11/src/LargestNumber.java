import java.util.Arrays;
import java.util.function.Function;

public class LargestNumber {

	public static void main(String[] args) {
		
Function<int[] ,Integer> largestNumber=
arr->Arrays.stream(arr).max().getAsInt();	

int[] number= {10,20,30,40,50};
System.out.println("largest Number :"+largestNumber.apply(number));
	}

}
