import java.util.function.Supplier;

public class OtpGenerator {
    public static void main(String[] args) {

        // Lambda expression to generate OTP
        Supplier<String> otpGenerator = () -> {
            char[] vowels = {'A', 'E', 'I', 'O', 'U'};
            
            // Random vowel
            int randomVowel = (int) (Math.random() * vowels.length);

            // Start OTP with that vowel
            StringBuffer buffer = new StringBuffer(String.valueOf(vowels[randomVowel]));

            // Add 5 random digits
            for (int i = 0; i < 5; i++) {
                buffer.append((int) (Math.random() * 10)); 
            }

            return buffer.toString();
        };

        for (int i = 0; i < 10; i++) {
            System.out.println(otpGenerator.get());
        }
    }
}
