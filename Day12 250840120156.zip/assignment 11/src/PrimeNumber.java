import java.util.Scanner;
import java.util.function.Function;

public class PrimeNumber {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Enter the number : ");
		int num = scanner.nextInt();

		// TODO Auto-generated method stub
		Function<Integer, Boolean> isPrime = (n) -> {
			if (num <= 1)
				return false;

			for (int i = 2; i <= num / 2; i++) {
				if (num % i == 0)
					return false;
			}
			return true;

		};
		if (isPrime.apply(num)) {
			System.out.println(num + " is prime number");
		} else if (num <= 1) {
			System.out.println(num + " is not prime number");
		} else {
			System.out.println(num + " is not prime number");
		}scanner.close();
	}

}
