

import java.util.Arrays;
import java.util.function.Function;

public class ReverseArray {

	public static void main(String[] args) {
		Function<int[], int[]> reverseArray = (arr) -> {

			int[] reversed = new int[arr.length];
			for (int i = 0; i < arr.length; i++) {
				reversed[i] = arr[arr.length - 1 - i];

			}
			return reversed;

		};

		int[] number = { 1, 2, 3, 4, 5 };
		System.out.println("Original Array: "+ Arrays.toString(number));

		int[] result = reverseArray.apply(number);

		System.out.println("Reversed Array : " + Arrays.toString(result));
	}
}