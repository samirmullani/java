import java.util.Arrays;
import java.util.function.Function;

public class SmallestNumber {

	public static void main(String[] args) {
		
Function<int[] ,Integer> SmallestNumber=
arr->Arrays.stream(arr).min().getAsInt();	

int[] number= {10,20,30,40,50};
System.out.println("Smallest Number  :"+SmallestNumber.apply(number));
	}

}