import java.util.List;
import java.util.stream.Collectors;

public class TransactionLamAmount {
    
	public List<Transactions> filterHighValueTransactions(List<Transactions> transactions) {
	    List<Transactions> filteredTransactions = transactions.stream()
	            .filter(tx -> tx.getTxAmount() > 5000)
	            .collect(Collectors.toList());
	    
	    System.out.println("\n--- Processing Filter: Transactions with amount > 5000 ---");
	    filteredTransactions.forEach(System.out::println);
	    
	    return filteredTransactions;
	}
}
