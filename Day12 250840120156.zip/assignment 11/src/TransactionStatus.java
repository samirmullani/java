import java.time.LocalDate;
	import java.util.ArrayList;
	import java.util.List;
	import java.util.Scanner;
	import java.util.stream.Collectors;
public class TransactionStatus {


		public static void main(String[] args) {
		List<Transactions> transactions=new ArrayList<Transactions>();
		Scanner scanner=new Scanner(System.in);
		final int NumOfTransaction=2;
		System.out.println("----Enter transaction details---");
		for(int i=1;i<=NumOfTransaction;i++) {
		System.out.println("enter transaction detail for transaction"+i+":");
			
		System.out.println("Enter id:");
		 int txid=scanner.nextInt();
		
		System.out.println("Enter Date(YYYY-MM-DD):");
		scanner.nextLine();
		String dateString=scanner.nextLine();
		LocalDate txDate=LocalDate.parse(dateString);
		
		System.out.println("Enter Amount:");
		int txAmount=scanner.nextInt();
		scanner.nextLine(); 
		
		System.out.println("Enter Status:");
		boolean txStatus=scanner.nextBoolean();
		scanner.nextLine(); 
		
		System.out.println("Enter arrears:");
		boolean txArrears=scanner.nextBoolean();
		
		scanner.nextLine(); 
		
		Transactions txTransaction=new Transactions(txid, txDate, txAmount, txStatus, txArrears);
		transactions.add(txTransaction);
		System.out.println("Tranaction "+i+"add to the collection");
		}
		scanner.close();
		// Display all transactions
	    System.out.println("\n==================================");
	    System.out.println("Contents of ALL transactions:");
	    transactions.forEach(System.out::println);
	    System.out.println("==================================");


	    TransactionStatus app = new TransactionStatus();
	    List<Transactions> failedTransactions = app.filterHighValueTransactions(transactions);


	    System.out.println("\nSummary of high-value transactions (status=false): " + failedTransactions.size() + " found.");
	    System.out.println("List representation: " +failedTransactions);
	}


	public List<Transactions> filterHighValueTransactions(List<Transactions> transactions) {
	    List<Transactions> filteredTransactions = transactions.stream()
	    		.filter(tx -> !tx.isTxStatus())
	            .collect(Collectors.toList());
	    
	    System.out.println("\n--- Processing Filter: Transactions with Status=false ---");
	    filteredTransactions.forEach(System.out::println);
	    
	    return filteredTransactions;
	}



	}


