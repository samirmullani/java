package otpgenerator;

import java.util.LinkedList;

import java.util.Random;

class otpstore {
	LinkedList<String> otpList = new LinkedList<>();

//synchronization used to generate otp
	public synchronized void generateotp() {
		Random rand = new Random();
		String otp = String.format("%4d", rand.nextInt(10000));
		otpList.add(otp);
		System.err.println("generated"+otp);
		
	}

//synchronization used to generate otp
	public synchronized void Confirmotp() {
		while (otpList.isEmpty()) {
			try {
				wait();
			} catch (Exception e) {
				System.out.println("list is empty");
			}
		}
		String otp = otpList.removeFirst();
		System.out.println("otp is deleted" + otp);

	}
}

class Producer extends Thread {
	otpstore store;

	Producer(otpstore store) {
		this.store = store;
	}

	public void run() {
		for (int i = 0; i < 5; i++) {
			store.generateotp();

			try {
				Thread.sleep(1500);
			} catch (Exception e) {
				System.out.println("generated");
			}
		}
	}
}

class Consumer extends Thread {
	otpstore store;

	Consumer(otpstore store) {
		this.store = store;
	}

	public void run() {
		for (int i = 0; i < 5; i++) {
			store.Confirmotp();

			try {
				Thread.sleep(2000);
			} catch (Exception e) {
				System.out.println("generated");
			}
		}
	}
}

public class OTPThreadDemo {
	public static void main(String[] args) {

		otpstore objOtpstore = new otpstore();
		Producer producer = new Producer(objOtpstore);
		Consumer consumer = new Consumer(objOtpstore);

		producer.start();
		consumer.start();

	}
}
