
public class Entry {

	public static void main(String[] args) {
		System.out.print("Enter the number of values you want to Enter: ");
		int size=Input.getInteger();
		int sum=0;
		for(int iTemp=0;iTemp<size;iTemp++) {
			System.out.print("Enter the value: ");
			int number=Input.getInteger();
			sum+=number;
		}
		System.out.print("The Sum of "+size+" numbers is : "+sum);
	}

}
