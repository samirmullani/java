
public class CommandLineArgs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int iTemp=0;iTemp<args.length;iTemp++)
				System.out.println(args[iTemp]);
	}

}
