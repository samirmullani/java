
public class Entry {
	public static void main(String [] args) {
		int choice;
		do {
			System.out.println("1. Add two Integer values.");
			System.out.println("2. Add two Float values.");
			System.out.println("3. Subtract two Integer values.");
			System.out.println("4. Subtract two Float values.");
			System.out.println("5. Multiply two Integer values.");
			System.out.println("6. Multiply two Float values.");
			System.out.println("7. Divide two Integer values.");
			System.out.println("8. Divide two Float values.");
			System.out.println("Press any other key to Exit");
			System.out.println("Enter your Choice");
			choice=Input.getInteger();
			switch(choice) {
				case 1:{
					int num1,num2;
					System.out.print("Enter Number 1: ");
					num1=Input.getInteger();
					System.out.print("Enter Number 2: ");
					num2=Input.getInteger();
					int result=Calculator.add(num1,num2);
					System.out.println("The Sum of "+num1+" and "+num2+ " is "+result+"\n");
				}
				break;
				case 2:{
					float num1,num2;
					System.out.print("Enter Number 1: ");
					num1=Input.getFloat();
					System.out.print("Enter Number 2: ");
					num2=Input.getFloat();
					float result=Calculator.add(num1,num2);
					System.out.println("The Sum of "+num1+" and "+num2+ " is "+result+"\n");
				}
				break;
				case 3:{
					int num1,num2;
					System.out.print("Enter Number 1: ");
					num1=Input.getInteger();
					System.out.print("Enter Number 2: ");
					num2=Input.getInteger();
					int result=Calculator.subtract(num1,num2);
					System.out.println("The Substraction of "+num1+" and "+num2+ " is "+result+"\n");
				}
				break;
				case 4:{
					float num1,num2;
					System.out.print("Enter Number 1: ");
					num1=Input.getFloat();
					System.out.print("Enter Number 2: ");
					num2=Input.getFloat();
					float result=Calculator.subtract(num1,num2);
					System.out.println("The Substraction of "+num1+" and "+num2+ " is "+result+"\n");
				}
				break;
				case 5:{
					int num1,num2;
					System.out.print("Enter Number 1: ");
					num1=Input.getInteger();
					System.out.print("Enter Number 2: ");
					num2=Input.getInteger();
					int result=Calculator.multiply(num1,num2);
					System.out.println("The Multiplication of "+num1+" and "+num2+ " is "+result+"\n");
				}
				break;
				case 6:{
					float num1,num2;
					System.out.print("Enter Number 1: ");
					num1=Input.getFloat();
					System.out.print("Enter Number 2: ");
					num2=Input.getFloat();
					float result=Calculator.multiply(num1,num2);
					System.out.println("The Multiplication of "+num1+" and "+num2+ " is "+result+"\n");
				}
				break;
				case 7:{
					int num1,num2;
					System.out.print("Enter Number 1: ");
					num1=Input.getInteger();
					System.out.print("Enter Number 2: ");
					num2=Input.getInteger();
					int result=Calculator.divide(num1,num2);
					if(result==-9999999) System.out.println("Division by 0 is not Possible\n");
					else System.out.println("The Division of "+num1+" and "+num2+ " is "+result+"\n");
				}
				break;
				case 8:{
					float num1,num2;
					System.out.print("Enter Number 1: ");
					num1=Input.getFloat();
					System.out.print("Enter Number 2: ");
					num2=Input.getFloat();
					float result=Calculator.divide(num1,num2);
					if(result==-9999999) System.out.println("Division by 0 is not Possible\n");
					else System.out.println("The Division of "+num1+" and "+num2+ " is "+result+"\n");
				}
				break;
				default:
					System.out.println("Thank You For Visiting!"+"\n");
					break;
			}
		}while(choice>=1 && choice<=8);
	}
}
