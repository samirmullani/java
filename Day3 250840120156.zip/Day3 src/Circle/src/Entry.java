
public class Entry {

	public static void main(String[] args) {
		System.out.print("Enter the Radius of the circle: ");
		double radius=Input.getDouble();
		double area=Calculate.area(radius);
		double perimeter=Calculate.perimeter(radius);
		System.out.println("Area of circle: "+area);
		System.out.println("Perimeter of circle: "+perimeter);
	}

}
