
public class CommandLineArgs {

	public static void main(String[] args) {
		for(int iTemp=0;iTemp<args.length;iTemp++)
				System.out.println(args[iTemp]);
	}

}
