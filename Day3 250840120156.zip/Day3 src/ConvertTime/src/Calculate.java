
public class Calculate {
	public void calculateTime(int seconds) {
		int second,minute,hour;
		second=seconds%60;
		seconds=seconds/60;
		minute=seconds%60;
		hour=seconds/60;
		System.out.println(hour+":"+minute+":"+second);
	}
}
