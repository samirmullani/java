
public class Entry {

	public static void main(String[] args) {
		System.out.print("Enter Time in Seconds: ");
		int seconds=Input.getInteger();
		Calculate objCalculate=new Calculate();
		objCalculate.calculateTime(seconds);
	}

}
