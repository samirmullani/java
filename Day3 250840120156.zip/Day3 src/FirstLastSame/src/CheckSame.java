
public class CheckSame {
	public static boolean checkSame(int [] arr) {
		if(arr[0]==arr[arr.length-1]) return true;
		return false;
	}
}
