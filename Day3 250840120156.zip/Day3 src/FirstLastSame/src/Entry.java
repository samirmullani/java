
public class Entry {

	public static void main(String[] args) {
		System.out.print("Enter Size of Array: ");
		int size=Input.getInteger();
		int [] array=new int [size];
		for(int iTemp=0;iTemp<size;iTemp++) {
			array[iTemp]=Input.getInteger();
		}
		System.out.println(CheckSame.checkSame(array));
	}
}
