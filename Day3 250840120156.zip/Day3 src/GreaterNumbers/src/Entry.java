
public class Entry {

	public static void main(String[] args) {
		int num1,num2,num3;
		System.out.print("Input the first number: ");
		num1=Input.getInteger();
		System.out.print("Input the second number: ");
		num2=Input.getInteger();
		System.out.print("Input the third number: ");
		num3=Input.getInteger();
		System.out.println("The Result is: "+Greater.greater(num1,num2,num3));
	}

}
