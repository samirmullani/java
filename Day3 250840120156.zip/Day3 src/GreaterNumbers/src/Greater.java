
public class Greater {
	public static boolean greater(int first,int second,int third) {
		if(first<second && second<third) return true;
		else return false;
	}
}
