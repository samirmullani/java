
public class Entry {

	public static void main(String[] args) {
		int [] oriArray=new int[7];
		System.out.println("Enter Array Elements: ");
		for(int iTemp=0;iTemp<7;iTemp++) {
			oriArray[iTemp]=Input.getInteger();
		}
		System.out.print("\nOriginal Array: ");
		for(int iTemp=0;iTemp<7;iTemp++) {
			System.out.print(oriArray[iTemp]+" ");
		}
		System.out.print("\nRotated Array: ");
		int [] rotArray=RotateArray.rotateArray(oriArray);
		for(int iTemp=0;iTemp<7;iTemp++) {
			System.out.print(rotArray[iTemp]+" ");
		}
	}

}
