
public class RotateArray {
	public static int[] rotateArray(int[] arr) {
		int [] rotArray=new int[7];
		for(int iTemp=6;iTemp>=0;iTemp--) {
			rotArray[6-iTemp]=arr[iTemp];
		}
		return rotArray;
	}
}
