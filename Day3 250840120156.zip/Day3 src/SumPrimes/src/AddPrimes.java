
public class AddPrimes {
	public int addPrimes() {
		int count=1;
		int sum=0;
		int num=2;
		while (count<=100) {
			if(CheckPrime.checkPrime(num)) {
				sum+=num;
				num++;
				count++;
			}
			else num++;
		}
		return sum;
	}
}
