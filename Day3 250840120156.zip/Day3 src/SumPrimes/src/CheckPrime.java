
public class CheckPrime {
	public static boolean checkPrime(int number) {
		for(int iTemp=2;iTemp<number;iTemp++) {
			if((number%iTemp)==0) return false;
		}
		return true;
	}
}
