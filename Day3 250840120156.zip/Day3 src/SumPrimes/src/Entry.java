
public class Entry {

	public static void main(String[] args) {
		AddPrimes objSum=new AddPrimes();
		System.out.println("The Sum of First 100 Prime Numbers is : "+objSum.addPrimes());
	}

}
