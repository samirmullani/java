
public class Entry {
	public static void main(String[] args) {
		int [] array= {1,2,3,4};
		UniqueValues.unique(array);
	}
}
