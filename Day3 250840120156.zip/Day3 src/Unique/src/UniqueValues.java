
public class UniqueValues {
	public static void unique(int [] array) {
		int count=0;
		for(int iTemp=0;iTemp<array.length;iTemp++) {
			for(int jTemp=0;jTemp<array.length;jTemp++) {
				if(jTemp!=iTemp) {
					for(int kTemp=0;kTemp<array.length;kTemp++) {
						if(kTemp!=iTemp && kTemp!=jTemp) {
							System.out.println(array[iTemp]*100+array[jTemp]*10+array[kTemp]);
							count++;
						}
					}
				}
			}
		}
		System.out.println("Total number of three digit numbers is "+count);
	}
}
