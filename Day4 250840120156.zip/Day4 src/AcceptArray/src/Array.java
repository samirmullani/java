
public class Array 
{
	public static void arrayInput(int[] array) 
	{
		for (int iTemp = 0; iTemp < array.length; iTemp++) 
		{
			array[iTemp] = Input.getInteger();
		}
	}

	public static void arrayDisplay(int[] array) 
	{
		for (int iTemp = 0; iTemp < array.length; iTemp++) 
		{
			System.out.print(array[iTemp] + " ");
		}
	}

	public static void arrayMultiply(int[] array1, int[] array2) 
	{
		for (int iTemp = 0; iTemp < array1.length; iTemp++) 
		{
			System.out.print(array1[iTemp] * array2[iTemp] + " ");
		}
	}

	public static void arraySortAscending(int[] array) 
	{
		for (int iTemp = 0; iTemp < array.length - 1; iTemp++) 
		{
			for (int jTemp = iTemp + 1; jTemp < array.length; jTemp++) 
			{
				if (array[iTemp] > array[jTemp]) 
				{
					int temp = array[iTemp];
					array[iTemp] = array[jTemp];
					array[jTemp] = temp;
				}
			}
		}
	}

	public static void arraySortDescending(int[] array) 
	{
		for (int iTemp = 0; iTemp < array.length - 1; iTemp++) 
		{
			for (int jTemp = iTemp + 1; jTemp < array.length; jTemp++) 
			{
				if (array[iTemp] < array[jTemp]) 
				{
					int temp = array[iTemp];
					array[iTemp] = array[jTemp];
					array[jTemp] = temp;
				}
			}
		}
	}

	public static void mergeArrays(int[] array1, int[] array2, int[] result) 
	{
		if (array1.length >= array2.length) 
		{
			for (int iTemp = 0; iTemp < array2.length; iTemp++) 
			{
				result[iTemp] = array1[iTemp];
				result[result.length - 1 - iTemp] = array2[iTemp];
			}
		} else 
		{
			for (int iTemp = 0; iTemp < array1.length; iTemp++) 
			{
				result[iTemp] = array1[iTemp];
				result[result.length - 1 - iTemp] = array2[iTemp];
			}
		}
	}

	public static int findIndex(int[] array, int target) 
	{
		for (int iTemp = 0; iTemp < array.length; iTemp++) 
		{
			if (array[iTemp] >= target)
				return iTemp;
		}
		return -1;
	}
	
	public static void countOccurrences(int[] array, int value) 
	{
        int count = 0;
        
        for (int num : array) 
        {
            if (num == value) 
            {
                count++;
            }
        }

        if (count > 0) {
            System.out.println(value + " appears " + count);
        }
    }
}