
public class Entry {

	public static void main(String[] args) {
		System.out.print("Enter the size of Array: ");
		int size=Input.getInteger();
		int [] array1=new int [size];
		int [] array2=new int [size];
		System.out.println("Enter the Values of First Array: ");
		Array.arrayInput(array1);
		System.out.println("Enter the Values of Second Array: ");
		Array.arrayInput(array2);
		System.out.print("Arrays after Multiplication: ");
		Array.arrayMultiply(array1, array2);
	}

}
