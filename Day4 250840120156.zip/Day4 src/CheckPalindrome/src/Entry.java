
public class Entry {

	public static void main(String[] args) {
		System.out.print("Input a positive Number: ");
		int number=Input.getInteger();
		if(PalindromeCheck.palindromeCheck(number)) {
			System.out.println(number+" is palindrome.");
		}
		else {
			System.out.println(number+" is not palindrome.");
		}
	}

}
