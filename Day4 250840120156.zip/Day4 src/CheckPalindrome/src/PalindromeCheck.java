
public class PalindromeCheck {
	public static boolean palindromeCheck(int number) {
		int temp=number;
		int reverse=0;
		while (temp>0) {
			reverse=(reverse*10)+temp%10;
			temp/=10;
		}
		if(reverse==number) return true;
		return false;
	}
}
