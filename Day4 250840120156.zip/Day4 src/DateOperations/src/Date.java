
public class Date {
	private int day;
	private int month;
	private int year;
	
	public int getDay() {
		return day;
	}

	public int getMonth() {
		return month;
	}
	
	public int getYear() {
		return year;
	}
	
	public void setDate(int day,int month,int year) {
		if(year>1900 && year<2500) {
			this.year=year;
			
			if(month>=1 && month<=12) {
				this.month=month;
				
				if(day>=1 && day<=28 && month==2 && (year%4!=0 || (year%400!=0 && year%100==0))) {
					this.day=day;
				}
				
				else if(day>=1 && day<=29 && month==2 && year%4==0) {
					this.day=day;
				}
				
				else if(day>=1 && day<=30 && (month==4||month==6||month==9||month==11)){
					this.day=day;
				}
				
				else if(day>=1 && day<=31 && (month==1||month==3||month==5||month==7||month==8||month==10||month==12)){
					this.day=day;
				}
				
				else this.day=-1;
			}
			
			else this.month=-1;
		}
		
		else this.year=-1;			
	}
	
	public void addDays(int days) {
		while (days>0){
			if(day!=-1 && month!=-1 && year!=-1){
				setDate(getDay()+1,getMonth(),getYear());
				if(day==-1 || day==0){
					setDate(1,getMonth()+1,getYear());
				
					if(month==-1){
						setDate(1,1,getYear()+1);
					}
				}
			}
			
			days--;
		}
	}
	
	public boolean compareDates(int days, int months, int years) {
		if(days==getDay() && months==getMonth() && years==getYear()) return true;
		return false;
	}
	
}
