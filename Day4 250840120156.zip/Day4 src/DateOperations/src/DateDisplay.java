
public class DateDisplay {
	static int check=0;
	public static void display(int day,int month,int year) {
		
		if (year==-1||month==-1||day==-1) {
			System.out.println("\nEnter Valid Date");
			System.out.println("---------------------------------\n");
			check=1;
		}
		else {
			System.out.println("\n"+day+"/"+month+"/"+year);
			System.out.println("---------------------------------\n");
			check=0;
		}
	}
}
