
public class Entry {

	public static void main(String[] args) {
		Date objDate=new Date();
		int choice;
		do {
			System.out.println("--------------MENU---------------");
			System.out.println("1. Set Date");
			System.out.println("2. Add Days");
			System.out.println("3. Add Months");
			System.out.println("4. Add Years");
			System.out.println("5. Compare Dates");
			System.out.println("Enter any other Integer to Exit");
			System.out.println("---------------------------------");
			System.out.print("\nEnter your Choice: ");
			choice=Input.getInteger();
			switch(choice) {
				case 1:{
					do {
						System.out.print("\nEnter the day: ");
						int day=Input.getInteger();
						System.out.print("Enter the month: ");
						int month=Input.getInteger();
						System.out.print("Enter the year: ");
						int year=Input.getInteger();
						objDate.setDate(day, month, year);
						DateDisplay.display(objDate.getDay(), objDate.getMonth(), objDate.getYear());
					}while(DateDisplay.check==1);
					break;
				}
				
				case 2:{
					System.out.print("\nEnter Number of days to add: ");
					int days=Input.getInteger();
					objDate.addDays(days);
					DateDisplay.display(objDate.getDay(), objDate.getMonth(), objDate.getYear());
					break;
				}
				
				case 3:{
					System.out.print("\nEnter Number of months to add: ");
					int months=Input.getInteger();
					objDate.addDays(months *30);
					DateDisplay.display(objDate.getDay(), objDate.getMonth(), objDate.getYear());
					break;
				}
				
				case 4:{
					System.out.print("\nEnter Number of years to add: ");
					int years=Input.getInteger();
					objDate.addDays(years *365);
					DateDisplay.display(objDate.getDay(), objDate.getMonth(), objDate.getYear());
					break;
				}
				case 5:{
					System.out.print("\nEnter the day: ");
					int days=Input.getInteger();
					System.out.print("Enter the month: ");
					int months=Input.getInteger();
					System.out.print("Enter the year: ");
					int years=Input.getInteger();
					if (objDate.compareDates(days, months, years)) {
						System.out.println("\nDate is Same");
						System.out.println("---------------------------------\n");
					}
					else {
						System.out.println("\nDate is not Same");
						System.out.println("---------------------------------\n");
					}
					break;
				}
				default:
					System.out.println("\nThanks For Visiting!");
					System.out.println("---------------------------------");
					break;

			}
		}while(choice>=1&& choice<=5);
		
	}

}
