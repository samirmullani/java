
public class Entry {

	public static void main(String[] args) {
		
		System.out.print("Enter the size of Array: ");
		int size=Input.getInteger();
		
		int[] array = new int[size];
		System.out.println("Enter values of Array: ");
		Array.arrayInput(array);

		for (int i = 0; i < array.length; i++) {
			boolean alreadyCounted = false;

			for (int j = 0; j < i; j++) {
				if (array[i] == array[j]) {
					alreadyCounted = true;
					break;
				}
			}

			if (!alreadyCounted) {
				Array.countOccurrences(array, array[i]);
			}
		}
	}
}
