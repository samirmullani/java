
public class Entry {

	public static void main(String[] args)
	{
		System.out.print("Enter the size of array: ");
		int size=Input.getInteger();
		int [] array = new int[size];
		System.out.println("Enter the values of the array: ");
		Array.arrayInput(array);
		System.out.print("Enter the Target Element");
		int target=Input.getInteger();
		int index=Array.findIndex(array, target);
		if(index==-1) System.out.println("Value to be inserted at: "+size);
		else System.out.println("Value can be found/inserted at: "+index);
	}

}
