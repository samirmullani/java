
public class Entry {

	public static void main(String[] args) {
		System.out.print("Enter the size of Array1: ");
		int size1=Input.getInteger();
		int [] array1=new int[size1];
		System.out.println("Enter the values of Array1: ");
		Array.arrayInput(array1);
		Array.arraySortAscending(array1);
		System.out.print("Enter the size of Array2: ");
		int size2=Input.getInteger();
		int [] array2=new int[size2];
		System.out.println("Enter the values of Array2: ");
		Array.arrayInput(array2);
		Array.arraySortAscending(array2);
		System.out.print("\nArray1: ");
		Array.arrayDisplay(array1);
		System.out.print("\nArray2: ");
		Array.arrayDisplay(array2);
		int [] result=new int[size1+size2];
		Array.mergeArrays(array1,array2,result);
		Array.arraySortAscending(result);
		System.out.print("\nMerged Array: ");
		Array.arrayDisplay(result);
	}

}
