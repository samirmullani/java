
public class Entry {

	public static void main(String[] args) {
		System.out.print("Enter the size of Array: ");
		int size=Input.getInteger();
		int [] array=new int [size];
		System.out.println("Enter values of Array: ");
		Array.arrayInput(array);
		Array.arrayDisplay(array);
		System.out.println("\n1. Sort in Ascending Order");
		System.out.println("2. Sort in Descending Order");
		int choice=Input.getInteger();
		if(choice==1) {
			Array.arraySortAscending(array);
			System.out.print("Ascending Array is: ");
			Array.arrayDisplay(array);
		}
		else if(choice==2) {
			Array.arraySortDescending(array);
			System.out.print("Descending Array is: ");
			Array.arrayDisplay(array);
		}
	}

}
