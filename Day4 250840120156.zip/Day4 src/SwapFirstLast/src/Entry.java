
public class Entry {

	public static void main(String[] args) {
		System.out.print("Enter the size of Array: ");
		int size=Input.getInteger();
		int [] array=new int [size];
		System.out.println("Enter values of Array: ");
		Array.arrayInput(array);
		System.out.print("\nArray Before Swap: ");
		Array.arrayDisplay(array);
		Swap.swap(array);
		System.out.print("\n\nArray After Swap: ");
		Array.arrayDisplay(array);
	}

}
