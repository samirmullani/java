
public class Swap {
	public static void swap(int [] array) {
		int temp=array[0];
		array[0]=array[array.length-1];
		array[array.length-1]=temp;
	}
}
