public class Input {
	public static String getInput() {
		try {
			byte [] arrayInput=new byte[100];
			int length=System.in.read(arrayInput);
			byte [] arrayFinal=new byte[length-2];
			System.arraycopy(arrayInput, 0, arrayFinal, 0, length-2);
			String objString=new String(arrayFinal);
			return objString;
		}
		catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}

	public static int getInteger() {
		return Integer.parseInt(Input.getInput());
	}

	public static float getFloat() {
		return Float.parseFloat(Input.getInput());
	}

	public static double getDouble() {
		return Double.parseDouble(Input.getInput());
	}
	
	public static String getString() {
		return Input.getInput();
	}
	
	public static char getCharacter() {
		return Input.getInput().charAt(0);
	}
}