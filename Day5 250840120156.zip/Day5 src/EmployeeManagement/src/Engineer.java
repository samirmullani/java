
public class Engineer extends Employee
{
	
	protected float overTime;
	
	public Engineer(String name, String address, int age, char gender, float basicSalary, float overTime)
	{
		super(name, address, age, gender, basicSalary);
		this.overTime = overTime;
	}

	@Override
	public float calculateSalary()
	{
		return basicSalary + overTime;
	}

	@Override
	public void display()
	{
		super.display();
		System.out.println("OverTime: " + this.overTime);
		System.out.println("Total Salary: " + this.calculateSalary());
		System.out.println("\n------------------------");
	}

}