
public class Entry
{

	public static void main(String[] args) 
	{
		Employee objEmployee[] = new Employee[100];
		
		int choice = 0;
		
		do {
			System.out.println("\n---------------MENU---------------");
			System.out.println("1. Add Employee");
			System.out.println("2. Display All");
			System.out.println("3. Save");
			System.out.println("4. Load");
			System.out.println("5. Sort");
			System.out.println("6. Exit");
			System.out.println("\n----------------------------------");
			System.out.print("\nEnter your Choice: ");
			choice = Input.getInteger();
			switch(choice)
			{ 
				case 1:
				{
					int empChoice;
					do {
						System.out.println("\n----------EMPLOYEE-MENU-----------");
						System.out.println("1. Add Manager");
						System.out.println("2. Add Engineer");
						System.out.println("3. Add Salesman");
						System.out.println("Press any other number to exit.");
						System.out.println("\n----------------------------------");
						System.out.print("\nEnter your Choice: ");
						empChoice = Input.getInteger();
						if(empChoice >= 1 && empChoice <= 3)
							Management.addEmployee(objEmployee,empChoice);
					}while(empChoice >= 1 && empChoice <= 3);
					break;
				}
				
				case 2:
				{
					Management.displayAll(objEmployee);
					System.out.println("\n----------------------------------");
					break;
				}
				
				case 3:
				{
					//For save function
					break;
				}
				
				case 4:
				{
					//For load function
					break;
				}
				
				case 5:
				{
					System.out.println("\n------------SORT-MENU-------------");
					System.out.println("1. Sort by Name in Ascending");
					System.out.println("2. Sort by Name in Descending");
					System.out.println("3. Sort by Designation");
					System.out.println("\n----------------------------------");
					System.out.print("\nEnter your Choice: ");
					int sortChoice = Input.getInteger();
					if(sortChoice >= 1 && sortChoice <= 3)
						Management.sortEmployee(objEmployee,sortChoice);
					else
						System.out.println("Invalid Choice");
					System.out.println("\n----------------------------------");
					break;
				}
				
				case 6:
				{
					System.out.println("Thank You for Visiting");
					System.out.println("\n----------------------------------");
					break;
				}
				
				default:
				{
					System.out.println("\nInvalid Choice");
					System.out.println("----------------------------------");
					break;
				}
					
			}
		} while(choice != 6);
		
	}

}
