
public class Management
{	
	static int count = 0;
	
	public static void addEmployee(Employee objEmployee[], int empChoice)
	{
		
		// Taking input for different employees
		System.out.print("Enter Name: ");
		String name = Input.getString();
		
		System.out.print("Enter Address: ");
		String address = Input.getString();
		
		System.out.print("Enter Age: ");
		int age = Input.getInteger();
		
		// Age Validation
		if (age > 80 || age < 18) 
		{
			System.out.println("\nInvalid Age");
			return;
		}
		
		// Gender Validation
		System.out.print("Enter Gender(M/F): ");
		char gender = Input.getCharacter();
		
		if( gender != 'M' && gender != 'm' && gender != 'F' && gender != 'f' )
		{
			System.out.println("\nInvalid Gender");
			return;
		}
		
		System.out.print("Enter Basic Salary: ");
		float basicSalary = Input.getFloat();
		
		if(empChoice == 1) //Choice 1 is Manager
		{
			System.out.print("Enter HRA: ");
			float hra = Input.getFloat();
			objEmployee[count++] = new Manager(name,address,age,gender,basicSalary,hra);
			
		}
		
		else if(empChoice == 2) //Choice 2 is Engineer
		{
			System.out.print("Enter OverTime: ");
			float overTime = Input.getFloat();
			objEmployee[count++] = new Engineer(name,address,age,gender,basicSalary,overTime);
		}
		
		else if(empChoice==3) //Choice 3 is Salesman
		{
			System.out.print("Enter Commission: ");
			float commission = Input.getFloat();
			objEmployee[count++] = new Salesman(name,address,age,gender,basicSalary,commission);
		}
		
		System.out.println("\nEmployee added Successfully");
		System.out.println("----------------------------------");
	}
	
	// Function to display all the objects in the array
	public static void displayAll(Employee objEmployee[])
	{
		for (int iTemp = 0 ; iTemp < count ; iTemp++)
		{
			objEmployee[iTemp].display();
		}
	}
	
	// Function to sort the objects in the array based on user input
	public static void sortEmployee(Employee objEmployee[], int sortChoice)
	{
		if (sortChoice == 1) //for sorting name in Ascending
		{
			for(int iTemp = 0 ; iTemp < count - 1 ; iTemp++)
			{
				for(int jTemp = iTemp + 1 ; jTemp < count ; jTemp++)
				{
					if(objEmployee[iTemp].getName().compareTo(objEmployee[jTemp].getName()) > 0)
					{
						Employee tempEmployee = objEmployee[iTemp];
						objEmployee[iTemp] = objEmployee[jTemp];
						objEmployee[jTemp] = tempEmployee;
					}
				}
			}
		}
		
		else if (sortChoice == 2) //for sorting name in Descending
		{
			for(int iTemp = 0 ; iTemp < count - 1 ; iTemp++)
			{
				for(int jTemp = iTemp + 1 ; jTemp < count ; jTemp++)
				{
					if(objEmployee[iTemp].getName().compareTo(objEmployee[jTemp].getName()) < 0)
					{
						Employee tempEmployee = objEmployee[iTemp];
						objEmployee[iTemp] = objEmployee[jTemp];
						objEmployee[jTemp] = tempEmployee;
					}
				}
			}
		}
		
		else if (sortChoice == 3) //for sort by designation
		{
			System.out.println("\n-----SORT-BY-DESIGNATION-MENU-----");
			System.out.println("1. Sort by Manager");
			System.out.println("2. Sort by Engineer");
			System.out.println("3. Sort by Salesman");
			System.out.println("\n----------------------------------");
			System.out.println("Enter your Choice: ");
			int desgChoice = Input.getInteger();
			
			if(desgChoice >= 1 && desgChoice <= 3)
			{
				if(desgChoice == 1) //
				{
					for(int iTemp = 0 ; iTemp < count ; iTemp++)
					{
						if(objEmployee[iTemp] instanceof Manager)
						{
							objEmployee[iTemp].display();
						}
					}
				}
				
				if(desgChoice == 2)
				{
					for(int iTemp = 0 ; iTemp < count ; iTemp++)
					{
						if(objEmployee[iTemp] instanceof Engineer)
						{
							objEmployee[iTemp].display();
						}
					}
				}
				
				if(desgChoice == 3)
				{
					for(int iTemp = 0; iTemp < count ; iTemp++)
					{
						if(objEmployee[iTemp] instanceof Salesman)
						{
							objEmployee[iTemp].display();
						}
					}
				}
			}
			else 
				System.out.println("\nInvalid Choice");
		}
		
	}
}
