
public class Manager extends Employee
{
	
	protected float hra;
	
	public Manager(String name, String address, int age, char gender, float basicSalary, float hra)
	{
		super(name, address, age, gender, basicSalary);
		this.hra = hra;
		
	}

	@Override
	public float calculateSalary()
	{
		return basicSalary + hra;
	}

	@Override
	public void display()
	{
		super.display();
		System.out.println("HRA: " + this.hra);
		System.out.println("Total Salary: " + this.calculateSalary());
		System.out.println("\n------------------------");
	}

}
