
public class Salesman extends Employee
{
	
	protected float commission;
	
	public Salesman(String name, String address, int age, char gender, float basicSalary,float commission)
	{
		super(name, address, age, gender, basicSalary);
		this.commission = commission;
	}

	@Override
	public float calculateSalary()
	{
		return basicSalary + commission;
	}

	@Override
	public void display()
	{
		super.display();
		System.out.println("Commission: " + this.commission);
		System.out.println("Total Salary: " + this.calculateSalary());
		System.out.println("\n------------------------");
	}

}
