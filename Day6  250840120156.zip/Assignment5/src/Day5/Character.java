package Day5;

 public class Character {

	public static void main(String[] args) {
		String str ="Java Exercises!";
		 System.out.println("original string = "+str);
		 
		 System.out.println("string at 0th position:"+str.charAt(0));
		 System.out.println("string at 10th position:"+str.charAt(10));

	}



}
