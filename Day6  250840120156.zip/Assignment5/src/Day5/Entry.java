package Day5;

public class Entry {

	public static void main(String[] args) {
		RegularPolygon[] arr = { new Square(), new EquilateralTriangle()};

		int totalSides = totalSides(arr);
		System.out.println(totalSides);
		
		for (RegularPolygon shape : arr) {
            System.out.println("Perimeter: " + getPerimeter(shape));
            System.out.println("Interior Angle (radians): " + getInteriorAngle(shape));
        }
	}

	public static int totalSides(RegularPolygon[] polygons) {
        int total = 0;
        for (RegularPolygon p : polygons) {
            total += p.getNumSides();
        }
        return total;
    }
	
	
	public static double getPerimeter(RegularPolygon arr) {
        return arr.getNumSides() * arr.getSideLength();
    }

    public static double getInteriorAngle(RegularPolygon polygon) {
        int n = polygon.getNumSides();
        return ((n - 2) *3.14 ) / n;
    }
}
