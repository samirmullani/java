package Day5;

public class EquilateralTriangle implements RegularPolygon {
    private double sideLength;

    
    

    public EquilateralTriangle(double sideLength) {
		
		this.sideLength = sideLength;
	}



	public EquilateralTriangle() {
		super();
		// TODO Auto-generated constructor stub
	}



	public int getNumSides() {
        return 3;
    }

    public double getSideLength() {
        return sideLength;
    }
}
