package Day5;

public class FindIndex {
	public static void main(String[] args) {
		String alphabet="The quick brown fox jumps over the lazy dog.";
		for (char ch='a';ch<='z';ch++) {
			int index=alphabet.indexOf(ch);
		
		System.out.print(ch+"->"+index+" ");
		}
	}

}
