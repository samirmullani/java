package Day5;

public class Lexicographically{
	public static void main(String[] args) {
		String s1="This is Exercise 1";
		String s2="This is Exercise 2";
		System.out.println(s1);
		System.err.println(s2);
		
		int result=s1.compareTo(s2);
		if(result<0) {
			System.out.println(s1+" is less than "+s2);
			
		}
		else
		{
			System.out.println(s1+" is greater than "+s2);
		}
	}

}
