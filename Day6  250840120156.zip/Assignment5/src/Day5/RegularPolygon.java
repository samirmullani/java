package Day5;

public interface RegularPolygon {

	int getNumSides();

	double getSideLength();

}
