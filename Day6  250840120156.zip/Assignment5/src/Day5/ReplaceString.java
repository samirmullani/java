package Day5;

public class ReplaceString {
	public static void main(String[]args)
	{
	String str="The quick brown fox jumps over the lazy dog";
	System.out.println("original string"+str);
	String newStr=str.replace("fox","cat");

	System.out.println(newStr);	

	}
}
