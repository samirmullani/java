package Day5;

public class ReverseString {
	public static void main(String[] args) {
		String s1="The quick brown fox jumps";
		System.out.println(s1);
		String reverse="";
		for (int i=s1.length()-1;i>=0;i--) {
			reverse=reverse+s1.charAt(i);
		}
		System.out.println(reverse);
	}
	


}
