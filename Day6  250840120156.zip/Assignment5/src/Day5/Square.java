package Day5;

public class Square implements RegularPolygon {
    private double sideLength;

    
    

    public Square(double sideLength) {
	
		this.sideLength = sideLength;
	}



	public Square() {
		super();
	}



	public int getNumSides() {
        return 4;
    }

    public double getSideLength() {
        return sideLength;
    }
}

