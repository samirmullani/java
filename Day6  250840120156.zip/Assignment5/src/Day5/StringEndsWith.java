package Day5;

public class StringEndsWith {

	public static void main(String[] args) {
		String s1="Python Exercises";
		String s2="Python excerise";
		System.out.println(s1.endsWith("se"));
		System.out.println(s2.endsWith("se"));

	}

}
