package Day5;

public class Uppercase {

	public static void main(String[] args) {
		String s1="The Quick BroWn FoX!";
		String s2=s1.toUpperCase();
		System.out.println(s2);

	}

}
