
public class Engineer extends Employee {

	protected float overTime;
	protected float OVERTIMECHARGE = 1000;

	public Engineer(String name, String address, int age, boolean gender, float basicSalary, float overtime) {
		super(name, address, age, gender, basicSalary);
		this.overTime = overtime;
	}

	public float getOverTime() {
		return overTime;
	}

	public void setOverTime(float overTime) {
		this.overTime = overTime;
	}

	@Override
	public float computeSalary() {
		return (basicSalary + (overTime * OVERTIMECHARGE));
	}

	@Override
	public String toString() {
		return "Name: " + name
				+ "\nAddress: " + address
				+ "\nAge: " + age
				+ "\nGender: " + gender
				+ "\nBasic Salary: " + basicSalary
				+ "\nOvertime: " + overTime
				+ "\nTotal salary: " + computeSalary();
	}

}
