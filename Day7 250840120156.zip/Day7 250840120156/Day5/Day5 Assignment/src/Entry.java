import com.cdac.utils.GenericLinkedList;

public class Entry {

    public static void main(String[] args) {

        GenericLinkedList<Employee> list = new GenericLinkedList<>();

        int choice;

        do {
            System.out.println("-------------MENU-------------");
            System.out.println("1. Add employee");
            System.out.println("2. Display all employees");
            System.out.println("3. Save");
            System.out.println("4. Load");
            System.out.println("5. Sort employees");
            System.out.println("6. Exit");
            System.out.println("------------------------------");

            System.out.println("Enter your choice");
            choice = ConsoleInput.getInt();

            switch (choice) {
                case 1: {
                    int choice1;

                    do {
                        System.out.println("-----------MENU-----------");
                        System.out.println("1. Add Manager");
                        System.out.println("2. Add Engineer");
                        System.out.println("3. Add Salesperson");
                        System.out.println("4. Exit");

                        System.out.println("Enter your choice");
                        choice1 = ConsoleInput.getInt();

                        if (choice1 > 0 && choice1 < 4) {
                            Employee employee = Management.addEmployee(choice1);
                            list.add(employee);
                        } else if (choice1 > 4) {
                            System.out.println("Wrong choice!");
                            break;
                        }

                    } while (choice1 != 4);

                    break;
                }

                case 2:
                    Management.display(list);
                    break;

                case 3:
                    System.out.println("SAVE not Implemented yet!!!");
                    // TODO Implement save to file method
                    break;

                case 4:
                    System.out.println("LOAD not Implemented yet!!!");
                    // TODO Implement load from file method
                    break;

                case 5: {
                    System.err.println("1.sort by name");
                    System.err.println("2.sort by designation");

                    int choice5 = ConsoleInput.getInt();

                    if (choice5 == 1) {
                        System.err.println("1.Ascending order");
                        System.err.println("2.Descending order");

                        int choice51 = ConsoleInput.getInt();

                        if (choice51 == 1 || choice51 == 2)
                            list = Management.sortEmployeesByName(choice51, list);
                        else {
                            System.out.println("Wrong choice!!!!!");
                        }
                    } else if (choice5 == 2) {

                        Management.sortByDesignation(list);

                    } else {
                        System.out.println("Wrong choice!!!!!");
                    }
                    break;

                }

                case 6:
                    System.out.println("Exiting program !!!");
                    break;

                default:
                    System.out.println("Incorrect choice! Enter correct choice from menu");
                    break;
            }

        } while (choice != 6);

    }

}
