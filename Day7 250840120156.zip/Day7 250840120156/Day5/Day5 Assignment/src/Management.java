import com.cdac.utils.GenericLinkedList;

public class Management {

    static int age;
    static String name, address;
    static boolean gender;
    static float basicSalary, hra, commission, overTime;

    static public Employee addEmployee(int x) {

        System.out.println("Enter the name");
        name = ConsoleInput.getString();
        System.out.println("Enter the address");
        address = ConsoleInput.getString();
        System.out.println("Enter the age");
        age = ConsoleInput.getInt();
        if (age < 18 || age > 70) {
            System.out.println("Invalid age!");
            // TODO implements exceptions

        }
        System.out.println("Enter the gender (true for male and false for female)");
        gender = ConsoleInput.getBoolean();
        System.out.println("Enter the basicSalary");
        basicSalary = ConsoleInput.getFloat();

        if (basicSalary < 1) {
            System.out.println("Salary can't be 0 or negative");
            // TODO implements exceptions
        }

        if (x == 1) {
            System.out.println("Enter the HRA");
            hra = ConsoleInput.getFloat();
            if (hra < 0) {
                System.out.println("HRA can't be negative");
                // TODO implements exceptions
            }

            Employee emp = new Manager(name, address, age, gender, basicSalary, hra);
            return emp;

        } else if (x == 2) {
            System.out.println("Enter the Overtime");
            overTime = ConsoleInput.getFloat();
            if (overTime < 0) {
                System.out.println("Overtime can't be negative");
                // TODO implements exceptions
            }

            Employee emp = new Engineer(name, address, age, gender, basicSalary, overTime);
            return emp;

        } else {
            System.out.println("Enter the Commission");
            commission = ConsoleInput.getFloat();
            if (commission < 0) {
                System.out.println("Commissionn can't be negative");
                // TODO implements exceptions
            }

            Employee emp = new SalesPerson(name, address, age, gender, basicSalary, commission);
            return emp;
        }
    }

    static public GenericLinkedList<Employee> sortEmployeesByName(int x, GenericLinkedList<Employee> list) {

        int n = list.getMaxCount();
        // Converting linked list into array for ease of sorting

        Employee[] empArray = new Employee[n];
        Employee emp = list.getFirst();
        for (int i = 0; i < n; i++) {
            empArray[i] = emp;
            emp = list.getNext();
        }

        list.getFirst();

        // Bubble sort on array
        for (int i = 0; i < n - 1; i++) {

            for (int j = i + 1; j < n; j++) {

                // compare names
                if (x == 1) {
                    if (empArray[i].getName().compareTo(empArray[j].getName()) > 0) {
                        // swap
                        Employee temp = empArray[i];
                        empArray[i] = empArray[j];
                        empArray[j] = temp;
                    }
                } else {
                    if (empArray[i].getName().compareTo(empArray[j].getName()) < 0) {
                        // swap
                        Employee temp = empArray[i];
                        empArray[i] = empArray[j];
                        empArray[j] = temp;
                    }
                }
            }
        }

        // Creating temporary generic linked list, and adding nodes
        // So, it can be returned
        GenericLinkedList<Employee> tempList = new GenericLinkedList<>();
        for (Employee tempEmp : empArray) {
            tempList.add(tempEmp);
        }

        return tempList;
    }

    static void sortByDesignation(GenericLinkedList<Employee> list) {

        System.out.println("Enter 1 for Manager");
        System.out.println("Enter 2 for Engineer");
        System.out.println("Enter 3 for Salesperson");
        int choice52 = ConsoleInput.getInt();

        Employee emp = list.getFirst();

        switch (choice52) {

            case 1:
                while (emp != null) {
                    if (emp instanceof Manager) {
                        System.out.println(emp.toString());
                        System.out.println("-------------------------");
                    }
                    emp = list.getNext();
                }
                break;

            case 2:
                while (emp != null) {
                    if (emp instanceof Engineer) {
                        System.out.println(emp.toString());
                        System.out.println("-------------------------");
                    }
                    emp = list.getNext();
                }
                break;

            case 3:
                while (emp != null) {
                    if (emp instanceof SalesPerson) {
                        System.out.println(emp.toString());
                        System.out.println("-------------------------");
                    }
                    emp = list.getNext();
                }
                break;

            default:
                System.out.println("Wrong choice !!!");
                break;
        }
        list.getFirst();

    }

    static void display(GenericLinkedList<Employee> list) {

        System.out.println("\nBelow are all the employees, and their details.\n");

        Employee emp = list.getFirst();

        while (emp != null) {
            System.out.println(emp.toString());
            System.out.println("-------------------------");

            emp = list.getNext();
        }
        list.getFirst();
    }
}
