
public class Manager extends Employee {

	protected float hra;

	public Manager(String name, String address, int age, boolean gender, float basicSalary, float hra) {
		super(name, address, age, gender, basicSalary);

		this.hra = hra;
	}

	public float getHra() {
		return hra;
	}

	public void setHra(float hra) {
		this.hra = hra;
	}

	@Override
	public float computeSalary() {
		return basicSalary + hra;
	}

	@Override
	public String toString() {
		return "Name: " + name
				+ "\nAddress: " + address
				+ "\nAge: " + age
				+ "\nGender: " + gender
				+ "\nBasic Salary: " + basicSalary
				+ "\nHRA: " + hra
				+ "\nTotal salary: " + computeSalary();
	}

}
