
public class SalesPerson extends Employee {

	protected float commission;

	public SalesPerson(String name, String address, int age, boolean gender, float basicSalary, float commission) {
		super(name, address, age, gender, basicSalary);

		this.commission = commission;
	}

	public float getCommission() {
		return commission;
	}

	public void setCommission(float commission) {
		this.commission = commission;
	}

	@Override
	public float computeSalary() {
		return basicSalary + commission;
	}

	@Override
	public String toString() {
		return "Name: " + name
				+ "\nAddress: " + address
				+ "\nAge: " + age
				+ "\nGender: " + gender
				+ "\nBasic Salary: " + basicSalary
				+ "\nCommission: " + commission
				+ "\nTotal salary: " + computeSalary();
	}

}
