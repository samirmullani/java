import com.cdac.utils.GenericLinkedList;
import com.cdac.utils.LinkedList;

public class Entry {

	public static void main(String[] args) {
//		LinkedList objLinkedList = new LinkedList();
//		objLinkedList.add("Sai");
//		objLinkedList.add("Sush");
//	    objLinkedList.add("Amit");
//
//	    objLinkedList.delete(1);
//	    
//		String data = (String) objLinkedList.getFirst();
//		
//		while(data != null)
//		{
//			System.out.println(data);
//			data = (String) objLinkedList.getNext();
//		}

	    
//	    System.out.println((String) objLinkedList.getLast());
//	    System.out.println((int) objLinkedList.getMaxCount());
	    
	    GenericLinkedList<String> genericList = new GenericLinkedList<>();
	    
	    genericList.add("Sai");
	    genericList.add("Sush");
	    genericList.add("Amit");

	    genericList.delete(1);
	    
	    String data = genericList.getFirst();
		
		while(data != null)
		{
			System.out.println(data);
			data = (String) genericList.getNext();
		}
		
	    System.out.println((String) genericList.getLast());
	    System.out.println((int) genericList.getMaxCount());

	}

}
