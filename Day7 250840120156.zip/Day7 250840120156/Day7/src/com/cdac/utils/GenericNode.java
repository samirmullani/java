package com.cdac.utils;

class GenericNode <T> {

	T data;
	
	GenericNode <T> next;
	
	GenericNode <T> previous;
	
	public GenericNode (T data) {
		super();
		this.data = data;
	}
	
}
