package com.cdac.utils;

public class LinkedList {

	Node start;

	Node end;

	Node current;

	int maxCount;

	public void add(Object data) {
		Node tempNode = new Node(data);

		if (start == null)
			start = end = current = tempNode;
		else {
			end.next = tempNode;
			tempNode.previous = end;
			end = tempNode;
		}
		maxCount++;
	}

	public void delete(int index) {
		if (start == null || index > maxCount - 1)
			return;
		if (start == end)
			start = end = current = null;
		else if (index == 0) {
			start = start.next;
			start.previous = null;
		} else if (index == maxCount - 1) {
			end = end.previous;
			end.next = null;
		} else {
			Node tempNode = start;

			for (int itemp = 0; itemp < index; itemp++, tempNode = tempNode.next)
				;

			tempNode.previous.next = tempNode.next;
			tempNode.next.previous = tempNode.previous;
		}

		current = start;
		maxCount--;
	}

	public Object getFirst() {
		if (start == null)
			return null;
		current = start;
		return current.data;
	}

	public Object getLast() {
		if (start == null)
			return null;
		current = end;
		return current.data;
	}

	public Object getNext() {
		if (start == null || current.next == null)
			return null;

		current = current.next;
		return current.data;
	}

	public Object getPrevious() {
		if (start == null || current.previous == null)
			return null;
		current = current.previous;
		return current.data;
	}

	public int getMaxCount() {
		return maxCount;
	}

}
