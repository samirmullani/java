package com.cdac.utils;

class Node {

	Object data;
	
	Node next;
	
	Node previous;

	public Node(Object date) {
		super();
		this.data = date;
	}
	
}
