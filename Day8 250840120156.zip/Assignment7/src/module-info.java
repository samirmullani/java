/**
 * 
 */
/**
 * 
 */
module Assignment7 {
	requires Console;
}