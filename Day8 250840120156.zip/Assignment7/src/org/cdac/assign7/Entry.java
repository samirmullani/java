package org.cdac.assign7;

public class Entry {

	public static void main(String[] args) {
		LinkedList<String> linkList = new LinkedList<String>();

		linkList.add("klm");
		linkList.add("efg");
		linkList.add("hij");
		linkList.add("abc");
		
		String data = linkList.getFirst();
		while(data != null) {
			System.out.println(data);
			data = linkList.getNext();		
		}
		linkList.sort();
		
		String data1 = linkList.getFirst();
		while(data1 != null) {
			System.out.println(data1);
			data1 = linkList.getNext();		
		}	
	}
}
