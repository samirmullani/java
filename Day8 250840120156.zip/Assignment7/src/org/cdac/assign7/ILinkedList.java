package org.cdac.assign7;

public interface ILinkedList<T> {
	void add(T data);
	void delete (int index);
	T getFirst();
	T getLast();
	T getNext();
	T getprevious();
	int getMaxCount();
}
