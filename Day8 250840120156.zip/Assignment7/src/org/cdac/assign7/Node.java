package org.cdac.assign7;

public class Node <T>
{
	T data;
	Node<T> next;
	Node<T> previous;
	
	public Node(T data ) {
		super();
		this.data=data;

		}
	
}
