package org.cdac.assign7;

import java.util.Scanner;

public class isEligibleToVote {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.print("Enter name: ");
            String name = sc.nextLine();

            System.out.print("Enter age: ");
            int age = sc.nextInt();

            if (age < 18)
                throw new ArithmeticException("Not eligible to vote.");
            else
                System.out.println(name + " is eligible to vote.");
        } 
        catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        } 
        finally {
            System.out.println("Program execution completed.");
            sc.close();
        }
    }
}

