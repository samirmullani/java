package org.cdac.assign7;

import java.util.Iterator;

public class iteratorLinkedlist {


	public abstract class LinkedList<T> implements Iterable<T>, ILinkedList<T> {
		public Node<T> start;
		public Node<T> end;
		public Node<T> current;
		public int maxCount;
		
		
		public class LinkedListIterator implements Iterator<T> {
		    
			Node<T> current = start;
		    Node<T> previous = null;
		    Node<T> beforePrevious = null;

		    public boolean hasNext() {
		        return current != null;
		    }

		    public T next() {
		        T data = current.data;
		        beforePrevious = previous;
		        previous = current;
		        current = current.next;
		        return data;
		    }
		}
		
		@Override
		public Iterator<T> iterator() {
			return new LinkedListIterator();
		}
		
		public void add(T data) {
			Node<T> tmpNode = new Node<T>(data);
			if (start == null) {
				start = end = current = tmpNode;
			} else {
				end.next = tmpNode;
				tmpNode.previous = end;
				end = tmpNode;
			}
			maxCount++;
		}

		public void delete(int index) {
			if (start == null || index > maxCount - 1)
				return;

			if (start == end) {
				start = end = current = null;
			} else if (index == 0) {
				start = start.next;
				start.previous = null;
			} else if (index == maxCount - 1) {
				end = end.previous;
				end.next = null;
			} else {
				Node<T> tmpNode = start;
				for (int iTmp = 0; iTmp < index; iTmp++, tmpNode = tmpNode.next)
					; // Loop to find the node at 'index'

				tmpNode.previous.next = tmpNode.next;
				tmpNode.next.previous = tmpNode.previous;

				current = start;
				maxCount--;
			}
		}

		public T getFirst() {
			if (start == null)
				return null;

			current = start;
			return current.data;
		}

		public T getLast() {
			if (start == null)
				return null;

			current = end;
			return current.data;
		}

		public T getNext() {
			if (start == null || current.next == null)
				return null;

			current = current.next;
			return current.data;
		}

		public T getPrevious() {
			if (start == null || current.previous == null)
				return null;

			current = current.previous;
			return current.data;

		}

		public int getMaxCount() {
			return maxCount;
		}


	}

}
