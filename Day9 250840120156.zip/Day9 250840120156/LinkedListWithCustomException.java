package Day9;

import java.io.Console;

//custom exception for empty list

class EmptyListException extends Exception {
 public EmptyListException(String message) {
     super(message);
 }
}

//custom exception for invalid position

class InvalidPositionException extends Exception {
 public InvalidPositionException(String message) {
     super(message);
 }
}



class Node {
 int data;
 Node next;

 Node(int data) {
     this.data = data;
     this.next = null;
 }
}


class CustomLinkedList {
 private Node head;

 public void add(int data) {
     Node newNode = new Node(data);
     if (head == null) head = newNode;
     else {
         Node temp = head;
         while (temp.next != null) temp = temp.next;
         temp.next = newNode;
     }
 }

 public void remove(int position) throws EmptyListException, InvalidPositionException {
     if (head == null) throw new EmptyListException("Cannot remove from empty list!");
     if (position <= 0) throw new InvalidPositionException("Position should be greater than 0!");
     if (position == 1) { head = head.next; return; }

     Node temp = head;
     for (int i = 1; i < position - 1; i++) {
         if (temp.next == null) throw new InvalidPositionException("Position out of range!");
         temp = temp.next;
     }
     if (temp.next == null) throw new InvalidPositionException("Position out of range!");
     temp.next = temp.next.next;
 }

 public void display() throws EmptyListException {
     if (head == null) throw new EmptyListException("List is empty!");
     Node temp = head;
     while (temp != null) {
         System.out.print(temp.data + " -> ");
         temp = temp.next;
     }
     System.out.println("null");
 }
}


public class LinkedListWithCustomException {
 public static void main(String[] args) {
     CustomLinkedList list = new CustomLinkedList();
     Console console = System.console();
     if (console == null) {
         System.out.println("No console available!");
         return;
     }

     boolean exit = false;
     while (!exit) {
         System.out.println("\nChoose an option:");
         System.out.println("1. Add");
         System.out.println("2. Remove");
         System.out.println("3. Display");
         System.out.println("4. Exit");
         String choiceStr = console.readLine("Enter choice: ");
         int choice = Integer.parseInt(choiceStr);

         try {
             switch (choice) {
                 case 1:
                     int num = Integer.parseInt(console.readLine("Enter number to add: "));
                     list.add(num);
                     break;
                 case 2:
                     int pos = Integer.parseInt(console.readLine("Enter position to remove: "));
                     list.remove(pos);
                     break;
                 case 3:
                     list.display();
                     break;
                 case 4:
                     exit = true;
                     break;
                 default:
                     System.out.println("Invalid choice!");
             }
         } catch (EmptyListException | InvalidPositionException e) {
             System.out.println("Error: " + e.getMessage());
         } catch (NumberFormatException e) {
             System.out.println("Invalid number format!");
         }
     }

     System.out.println("Program executed");
 }
}
