package Day9;

import java.io.*;

public class fileiodemo {
    private static final int SHIFT = 3;

    // Encryption method
    public static String encrypt(String data) {
        StringBuilder encrypted = new StringBuilder();
        for (char c : data.toCharArray()) {
            encrypted.append((char) (c + SHIFT));
        }
        return encrypted.toString();
    }

    // Decryption method
    public static String decrypt(String data) {
        StringBuilder decrypted = new StringBuilder();
        for (char c : data.toCharArray()) {
            decrypted.append((char) (c - SHIFT));
        }
        return decrypted.toString();
    }

    public static void main(String[] args) {
        FileOutputStream fileOut = null;
        FileInputStream fileIn = null;

        try {
            File file = new File("C:\\Users\\samir\\OneDrive\\Desktop\\java.txt");

            // Check karega file exists h ya nhi
            if (!file.exists()) {
                System.out.println("File does not exist! Cannot save data.");
                return; 
            }

            System.out.println("Enter text data: ");
            byte[] inputBuffer = new byte[200];
            int bytesRead = System.in.read(inputBuffer);

            String data = new String(inputBuffer, 0, bytesRead).trim();
            String encryptedData = encrypt(data); //  writing k pehle encrypt hoga

            // Write encrypted data to file
            fileOut = new FileOutputStream(file, true);
            fileOut.write(encryptedData.getBytes());
            fileOut.write('\n');
            System.out.println("File saved successfully (Encrypted).");

            
            //yaha file read hogi
            
            fileIn = new FileInputStream(file);
            byte[] readData = new byte[(int) file.length()];
            fileIn.read(readData);

            String fileContent = new String(readData);
            System.out.println("\nEncrypted File Content:");
            System.out.println(fileContent);

            System.out.println("\nDecrypted File Content:");
            String[] lines = fileContent.split("\n");
            for (String line : lines) {
                System.out.println(decrypt(line));
            }

        } catch (FileNotFoundException e) {
            System.out.println("File not found!");
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("IO Error!");
            e.printStackTrace();
        } finally {
            try {
                if (fileOut != null)
                    fileOut.close();
                if (fileIn != null)
                    fileIn.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
