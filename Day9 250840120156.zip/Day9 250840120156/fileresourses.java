package Day9;

import java.io.*;

public class fileresourses {
    private static final int SHIFT = 3;

    // encryption method
    public static String encrypt(String data) {
        StringBuilder encrypted = new StringBuilder();
        for (char c : data.toCharArray()) {
            encrypted.append((char) (c + SHIFT));
        }
        return encrypted.toString();
    }

    // decryption method
    
    public static String decrypt(String data) {
        StringBuilder decrypted = new StringBuilder();
        for (char c : data.toCharArray()) {
            decrypted.append((char) (c - SHIFT));
        }
        return decrypted.toString();
    }

    public static void main(String[] args) {
        File file = new File("C:\\Users\\samir\\OneDrive\\Desktop\\java.txt");

      
        if (!file.exists()) {
            System.out.println("File does not exist! Cannot save data.");
            return;
        }

        try {
            System.out.println("Enter text data: ");
            byte[] inputBuffer = new byte[200];
            int bytesRead = System.in.read(inputBuffer);

            String data = new String(inputBuffer, 0, bytesRead).trim();
            String encryptedData = encrypt(data);

            // Write encrypted data using try-with-resources
            
            try (FileOutputStream fileOut = new FileOutputStream(file, true)) {
                fileOut.write(encryptedData.getBytes());
                fileOut.write('\n');
                System.out.println("File saved successfully (Encrypted).");
            }

            // Read file content using try-with-resources
            
            try (FileInputStream fileIn = new FileInputStream(file)) {
                byte[] readData = new byte[(int) file.length()];
                fileIn.read(readData);

                String fileContent = new String(readData);
                System.out.println("\nEncrypted File Content:");
                System.out.println(fileContent);

                System.out.println("\nDecrypted File Content:");
                String[] lines = fileContent.split("\n");
                for (String line : lines) {
                    System.out.println(decrypt(line));
                }
            }

        } catch (IOException e) {
            System.out.println("IO Error!");
            e.printStackTrace();
        }
    }
}
