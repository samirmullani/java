/*package Day9;
public class main {
 public static void checkAge(int age) throws AgeException {
     if (age < 18) {
         throw new AgeException("Age is less than 18, Access denied.");
     } else {
         System.out.println("Age is fine, Access granted.");
     }
 }

 public static void main(String[] args) {
     int age = 19; 

     try {
         checkAge(age); 
     } catch (AgeException e) {
         System.out.println("Caught Exception: " + e.getMessage());
     } finally {
         System.out.println("Thank you!!");
     }

    
 }
}
*/

package Day9;

import java.io.Console;

public class main {

    public static void checkAge(int age) throws AgeException {
        if (age < 18) {
            throw new AgeException("Age is less than 18, Not Eligible For Vote");
        } else {
            System.out.println("Age is fine, Eligible For Vote");
        }
    }

    public static void main(String[] args) throws Exception {
        Console console = System.console();

       
        System.out.print("Enter your age: ");

        int age = 0;
        int ch;
        while ((ch = System.in.read()) != '\n') { 
            if (ch >= '0' && ch <= '9') {
                age = age * 10 + (ch - '0'); 
            }
        }

        try {
            checkAge(age);
        } catch (AgeException e) {
            System.out.println( e.getMessage());
        } finally {
            System.out.println("Thank you!!");
        }
    }
}

